import logo from "./logo.svg";
import "./App.css";
import TodoList from "./Components/TodoList";

function App() {
  return <TodoList />;
}

export default App;
